Use this patch file in order to strip the textures from the Ascension Extended Character Frame section.
If there is already a patch file with Patch-Y.mpq then use another letter.

The location to place the file is inside the Data folder of your Client install.

If you installed into the default location then you will find it in:

Ascension Launcher\resources\client\Data\

You will know you found the proper install directory when you see several other Patch-[A-Z].mpq files.