Use this patch file in order to strip the textures from the Ascension Extended Character Frame section.
If there is already a patch file with Patch-Y.mpq then use another letter.

The location to place the file is inside Ascension Launcher\resources\client\Data